.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # /usr/share/elasticsearch/bin/elasticsearch-setup-passwords auto

Take note of the password for the ``elastic`` user since it will be used later on.


.. End of include file
