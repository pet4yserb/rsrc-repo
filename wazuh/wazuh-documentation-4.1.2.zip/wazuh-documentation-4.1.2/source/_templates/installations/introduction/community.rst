.. Copyright (C) 2021 Wazuh, Inc.

In case of having questions or needing assistance, the following resources are available:

- `Google group <https://groups.google.com/forum/#!forum/wazuh>`_: in our mailing list you can share your questions and thoughts with our users community.
- `GitHub repositories <https://github.com/wazuh>`_: here you can submit issues and contribute to the project development. We happily welcome, review and accept pull requests.
- `Slack channel <https://wazuh.com/community/join-us-on-slack>`_: join users community channel to chat with our team members and other users.

In addition, we provide `professional support, training and consulting services <https://wazuh.com/professional-services/>`_.

.. End of file
