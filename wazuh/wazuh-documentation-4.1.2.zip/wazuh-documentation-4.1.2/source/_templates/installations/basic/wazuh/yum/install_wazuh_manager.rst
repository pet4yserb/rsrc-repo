.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # yum install wazuh-manager

.. End of include file
