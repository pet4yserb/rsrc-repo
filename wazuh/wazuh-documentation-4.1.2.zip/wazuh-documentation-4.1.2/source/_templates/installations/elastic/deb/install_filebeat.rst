.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

    # apt-get install filebeat

.. End of include file
