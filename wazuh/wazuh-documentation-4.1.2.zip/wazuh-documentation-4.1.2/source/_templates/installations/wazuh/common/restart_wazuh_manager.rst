.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::


  .. group-tab:: Systemd


    .. code-block:: console

      # systemctl restart wazuh-manager


  .. group-tab:: SysV Init

    .. code-block:: console

      # service wazuh-manager restart

.. End of include file

