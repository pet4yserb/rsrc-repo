.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # zypper install wazuh-agent

.. End of include file
