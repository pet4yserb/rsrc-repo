.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # filebeat setup --index-management -E setup.template.json.enabled=false

.. End of include file
