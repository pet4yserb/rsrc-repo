.. Copyright (C) 2021 Wazuh, Inc.

.. _compliance:

Compliance
==========

.. toctree::
    :maxdepth: 1
    :caption: Contents

    pci-dss/index
    gdpr/index
