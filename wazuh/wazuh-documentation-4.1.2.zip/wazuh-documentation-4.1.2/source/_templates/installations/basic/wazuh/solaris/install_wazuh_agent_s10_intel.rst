.. Copyright (C) 2021 Wazuh, Inc.

The Wazuh agent for Solaris 10 i386 can be downloaded from our :ref:`packages list<packages>` or directly from here: `Solaris 10 i386 package  <https://packages.wazuh.com/4.x/solaris/i386/10/wazuh-agent_v4.1.2-sol10-i386.pkg>`_. The current version has been tested on Solaris 10 i386 version 5.10. Install the agent as follows:

.. code-block:: console

  # pkgadd -d wazuh-agent_v4.1.2-sol10-i386.pkg

.. End of include file
