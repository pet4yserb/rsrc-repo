.. Copyright (C) 2021 Wazuh, Inc.

.. _development:

Development
===========

.. meta::
  :description: Find useful technical documentation about how Wazuh works, suitable for developers and tech enthusiasts.

This section contains technical documentation for developers.

.. topic:: Contents

    .. toctree::
        :maxdepth: 2

        client-keys
        message-format
        makefile
        wazuh-cluster
        packaging/index
        wazuh-logtest
