.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::


  .. tab:: Systemd


    .. code-block:: console

      # systemctl start wazuh-api


  .. tab:: SysV Init

    .. code-block:: console

      # service wazuh-api start

.. End of include file

