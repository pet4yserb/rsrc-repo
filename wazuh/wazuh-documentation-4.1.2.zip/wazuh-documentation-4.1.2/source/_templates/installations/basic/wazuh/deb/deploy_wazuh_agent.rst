.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # WAZUH_MANAGER="10.0.0.2" apt-get install wazuh-agent

.. End of include file
