.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::


  .. tab:: Systemd


    .. code-block:: console

      # systemctl stop filebeat
      # systemctl stop kibana


  .. tab:: SysV Init

    .. code-block:: console

      # service filebeat stop
      # service kibana stop

.. End of include file
