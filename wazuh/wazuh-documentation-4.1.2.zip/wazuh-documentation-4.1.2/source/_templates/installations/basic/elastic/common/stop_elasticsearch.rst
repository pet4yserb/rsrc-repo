.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::


  .. tab:: Systemd


    .. code-block:: console

      # systemctl stop elasticsearch


  .. tab:: SysV Init

    .. code-block:: console

      # service elasticsearch stop

.. End of include file
