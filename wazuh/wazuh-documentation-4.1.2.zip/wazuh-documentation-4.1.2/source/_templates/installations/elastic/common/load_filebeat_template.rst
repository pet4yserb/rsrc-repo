.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console
  
  # curl -so /etc/filebeat/wazuh-template.json https://raw.githubusercontent.com/wazuh/wazuh/4.1/extensions/elasticsearch/7.x/wazuh-template.json
  # chmod go+r /etc/filebeat/wazuh-template.json

.. End of include file
