.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::

    .. group-tab:: APT
        
        .. code-block:: console

            # apt install unzip wget

    .. group-tab:: Yum
        
        .. code-block:: console

            # yum install wget unzip

.. End of include file
