.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # sed -i "s/^deb/#deb/" /etc/apt/sources.list.d/wazuh.list
  # sed -i "s/^deb/#deb/" /etc/apt/sources.list.d/elastic-7.x.list
  # apt-get update

.. End of include file
