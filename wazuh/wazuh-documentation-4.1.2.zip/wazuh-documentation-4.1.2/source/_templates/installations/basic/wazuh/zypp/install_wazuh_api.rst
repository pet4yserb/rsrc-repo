.. Copyright (C) 2021 Wazuh, Inc.

#. Install NodeJS:

    .. code-block:: console

      # zypper install nodejs

#. Install the Wazuh API. It will update NodeJS if necessary:

    .. code-block:: console

      # zypper install wazuh-api


.. End of include file
