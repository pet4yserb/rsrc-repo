.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # zypper install opendistroforelasticsearch

.. End of include file
