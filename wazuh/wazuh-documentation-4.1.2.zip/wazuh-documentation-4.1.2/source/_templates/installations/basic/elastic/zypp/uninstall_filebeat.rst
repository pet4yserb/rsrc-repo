.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # zypper remove filebeat

.. End of include file
