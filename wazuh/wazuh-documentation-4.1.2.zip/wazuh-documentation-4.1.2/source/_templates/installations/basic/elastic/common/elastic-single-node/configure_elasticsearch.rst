.. Copyright (C) 2021 Wazuh, Inc.

Once Elasticsearch is installed it can be configured by downloading the file ``/etc/elasticsearch/elasticsearch.yml``:

.. code-block:: console

  # curl -so /etc/elasticsearch/elasticsearch.yml https://raw.githubusercontent.com/wazuh/wazuh-documentation/4.1/resources/elastic-stack/elasticsearch/7.x/elasticsearch.yml

.. End of include file
