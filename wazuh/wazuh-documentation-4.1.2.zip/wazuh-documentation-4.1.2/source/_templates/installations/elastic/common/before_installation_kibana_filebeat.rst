.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::

        .. group-tab:: Yum

            Install all the required utilities:

                .. code-block:: console

                    # yum install curl


                    
        .. group-tab:: APT

            Install all the required utilities:

                .. code-block:: console

                    # apt install curl apt-transport-https lsb-release gnupg2


                    
        .. group-tab:: ZYpp

            Install all the required utilities:

                .. code-block:: console

                    # zypper install curl                    

.. End of include file
