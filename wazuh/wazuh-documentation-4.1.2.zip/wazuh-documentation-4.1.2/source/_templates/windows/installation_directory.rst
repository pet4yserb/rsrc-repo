.. Copyright (C) 2021 Wazuh, Inc.

The Wazuh agent's installation directory depends on the architecture of the host:

 - ``C:\Program Files (x86)\ossec-agent`` for ``x86_64`` hosts.
 - ``C:\Program Files\ossec-agent`` for ``x86`` hosts.

 .. note::

  This guide supposes that the Wazuh agent is installed in a ``x86_64`` host. The installation path will be: ``C:\Program Files (x86)\ossec-agent``.

.. End of include file
