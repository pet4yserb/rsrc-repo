.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # yum remove filebeat

.. End of include file
