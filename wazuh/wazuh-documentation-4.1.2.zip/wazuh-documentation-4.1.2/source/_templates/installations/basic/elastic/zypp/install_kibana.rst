.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # zypper install kibana-7.10.2

.. End of include file
