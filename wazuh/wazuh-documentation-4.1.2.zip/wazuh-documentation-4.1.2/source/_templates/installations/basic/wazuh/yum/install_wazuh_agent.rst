.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # yum install wazuh-agent

.. End of include file
