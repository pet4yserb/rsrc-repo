.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: yaml

  output.elasticsearch.password: <elasticsearch_password>

Replace ``elasticsearch_password`` with the previously generated password for ``elastic`` user.


.. End of include file
