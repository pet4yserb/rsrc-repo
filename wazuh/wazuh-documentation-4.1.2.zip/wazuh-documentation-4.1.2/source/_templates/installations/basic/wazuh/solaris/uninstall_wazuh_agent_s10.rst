.. Copyright (C) 2021 Wazuh, Inc.

To uninstall the agent in Solaris 10:

.. code-block:: console

  # pkgrm wazuh-agent

.. End of include file
