.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::

 .. group-tab:: Powershell

  .. code-block:: console

   # Restart-Service -Name wazuh

 .. group-tab:: Windows cmd

  .. code-block:: console

   # net stop wazuh
   # net start wazuh

.. End of include file
