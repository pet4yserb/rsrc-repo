.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # sed -i "s/^enabled=1/enabled=0/" /etc/zypp/repos.d/elastic.repo

.. End of include file
