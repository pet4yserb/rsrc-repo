.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # apt-get install opendistroforelasticsearch-kibana

.. End of include file
