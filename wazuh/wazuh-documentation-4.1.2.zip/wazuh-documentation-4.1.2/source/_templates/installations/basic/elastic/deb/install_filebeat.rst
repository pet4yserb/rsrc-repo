.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # apt-get install filebeat=7.10.2

.. End of include file
