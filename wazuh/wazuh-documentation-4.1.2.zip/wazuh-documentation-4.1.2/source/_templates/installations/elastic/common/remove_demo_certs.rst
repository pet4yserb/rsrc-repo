.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

    # rm /etc/elasticsearch/esnode-key.pem /etc/elasticsearch/esnode.pem /etc/elasticsearch/kirk-key.pem /etc/elasticsearch/kirk.pem /etc/elasticsearch/root-ca.pem -f

.. End of include file
