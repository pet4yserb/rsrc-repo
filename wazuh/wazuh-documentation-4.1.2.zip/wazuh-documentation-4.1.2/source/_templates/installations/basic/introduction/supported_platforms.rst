.. Copyright (C) 2021 Wazuh, Inc.

Wazuh and Elastic Stack components can be installed, deployed and used in the following platforms:

* Operating systems: Linux, Windows, macOS, Solaris, AIX, HP-UX for Wazuh agent. Linux for Wazuh server and Elastic Stack.
* Cloud providers VM: Amazon Web Services (AWS), Microsoft Azure, Google Cloud Platform (GCP), Digital Ocean, Wazuh Cloud.
* Virtualization: VMware, Virtualbox, OpenStack.
* Containers: Docker, Kubernetes.

.. End of file
