.. Copyright (C) 2021 Wazuh, Inc.

# Create the repository file:

  .. code-block:: console

    # curl https://d3g5vo6xdbdb9a.cloudfront.net/yum/opendistroforelasticsearch-artifacts.repo -o /etc/yum.repos.d/opendistroforelasticsearch-artifacts.repo

.. End of include file
