.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

 # /Library/Ossec/bin/ossec-control restart

.. End of include file
