.. Copyright (C) 2021 Wazuh, Inc.

.. _deployment:

Deployment
==========

.. toctree::
   :maxdepth: 2

   deploying-with-puppet/index
   deploying-with-ansible/index
   virtual-machine/virtual-machine
