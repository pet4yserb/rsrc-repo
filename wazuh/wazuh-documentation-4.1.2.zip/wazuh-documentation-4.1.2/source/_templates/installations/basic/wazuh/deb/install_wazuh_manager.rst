.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # apt-get install wazuh-manager

.. End of include file
