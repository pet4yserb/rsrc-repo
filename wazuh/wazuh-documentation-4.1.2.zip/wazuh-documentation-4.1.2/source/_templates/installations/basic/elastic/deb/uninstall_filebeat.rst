.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # apt-get remove filebeat

The Filebeat complete file removal can be accomplished with the following command:

.. code-block:: console

  # apt-get remove --purge filebeat

.. End of include file
