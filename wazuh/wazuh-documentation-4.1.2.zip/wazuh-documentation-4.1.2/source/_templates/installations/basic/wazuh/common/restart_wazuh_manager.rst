.. Copyright (C) 2021 Wazuh, Inc.

.. tabs::


  .. tab:: Systemd


    .. code-block:: console

      # systemctl restart wazuh-manager


  .. tab:: SysV Init

    .. code-block:: console

      # service wazuh-manager restart

.. End of include file

