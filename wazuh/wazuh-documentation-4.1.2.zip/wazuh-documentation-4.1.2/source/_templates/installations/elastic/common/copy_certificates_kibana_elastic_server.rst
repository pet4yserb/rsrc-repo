.. Copyright (C) 2021 Wazuh, Inc.

.. code-block:: console

  # mkdir /etc/kibana/certs/
  # cp /etc/elasticsearch/certs/kibana.pem /etc/kibana/certs/kibana.pem
  # cp /etc/elasticsearch/certs/kibana.key /etc/kibana/certs/kibana.key


.. End of copy_certificates_kibana_elastic_server.rst
